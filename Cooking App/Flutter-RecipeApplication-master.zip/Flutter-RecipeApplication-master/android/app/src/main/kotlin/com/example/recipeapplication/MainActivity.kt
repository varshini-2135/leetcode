package com.example.recipeapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
